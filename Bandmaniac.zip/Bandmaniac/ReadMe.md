﻿This is a learning project developed for only educational purposes, studied by Alp Özallı. Inspired and educational from Paul Hudson who is a developer and made a live YouTube stream for a charity about “your first IOS app with SwiftUI”. 	

About Bandmaniac

Bandmaniac is a small wikipedia consists the local rock bands in Turkey. MapKit is included so you can travel around map with your fingers to know where bands are located.
