//
//  Band.swift
//  Bandmaniac
//
//  Created by Alp Özallı on 08.01.2021.
//

import Foundation
struct Band: Decodable, Identifiable {
    let id: Int
    let name: String
    let city: String
    let description: String
    let albums: String
    let years: Int
    let latitude: Double
    let longitude: Double
    let heroPicture: String
    let advisory: String

    static let example = Band(id: 1, name: "Duman", city: "Istanbul", description: "duman is a turkish rock band", albums: "Albums will place here", years: 23,latitude:41.015137,longitude:28.979530, heroPicture: "Duman", advisory: "traditional turkish music with grunge")
}
