//
//  ContentView.swift
//  Bandmaniac
//
//  Created by Alp Özallı on 08.01.2021.
//

import SwiftUI

struct ContentView: View {
    let band: Band

    var body: some View {
        ScrollView {
            Image(band.heroPicture)
                .resizable()
                .scaledToFit()

            Text(band.name)
                .font(.largeTitle)
                .bold()
                .multilineTextAlignment(.center)

            Text(band.city)
                .font(.title3)
                .foregroundColor(.secondary)

            Text(band.description)
                .padding(.horizontal)

            Text("Albums")
                .font(.title3)
                .bold()
                .padding(.top)

            Text(band.albums)
                .padding(.horizontal)
        }
        .navigationTitle("Discover")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            NavigationView {
                ContentView(band: Band.example)
            }
            NavigationView {
                ContentView(band: Band.example)
            }
        }
    }


}
