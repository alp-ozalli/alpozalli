//
//  BandmaniacApp.swift
//  Bandmaniac
//
//  Created by Alp Özallı on 08.01.2021.
//

import SwiftUI
@main
struct BandmaniacApp: App {
    @StateObject var bands = Bands()
    var body: some Scene {
        WindowGroup {
            NavigationView {
                ContentView(band: Bands().primary)
                }
            .tabItem {
                Image(systemName: "airplane.circle.fill")
                Text("Discover")
            }
            NavigationView {
                TurkeyView()
            }
            .tabItem {
                Image(systemName: "star.fill")
                Text("Band Locations")
            }
            NavigationView {
                TipsView()
            }
            .tabItem {
                Image(systemName: "list.bullet")
                Text("Tips")
            }
            .environmentObject(bands)
        }
       
    }
}



