//
//  Bands.swift
//  Bandmaniac
//
//  Created by Alp Özallı on 08.01.2021.
//

import Foundation

class Bands: ObservableObject {
    let places: [Band]
    var primary: Band {
        places[0]
    }

    init() {
        let url = Bundle.main.url(forResource: "bands", withExtension: "json")!
        let data = try! Data(contentsOf: url)
        places = try! JSONDecoder().decode([Band].self, from: data)
    }
}
