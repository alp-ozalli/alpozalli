//
//  Tip.swift
//  Bandmaniac
//
//  Created by Alp Özallı on 08.01.2021.
//

import Foundation

struct Tip: Decodable {
    let text: String
    let children: [Tip]?
}
