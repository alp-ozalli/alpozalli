//
//  TurkeyView.swift
//  Bandmaniac
//
//  Created by Alp Özallı on 08.01.2021.
//

import MapKit
import SwiftUI

struct TurkeyView: View {
    @EnvironmentObject var bands: Bands
    @State var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 38.963745, longitude: 35.243322),
        span: MKCoordinateSpan(latitudeDelta: 10, longitudeDelta: 10)
    )

    var body: some View {
        Map(coordinateRegion: $region, annotationItems: bands.places) { band in
            MapAnnotation(coordinate: CLLocationCoordinate2D(latitude: band.latitude, longitude: band.longitude)) {
                NavigationLink(destination: ContentView(band: band)) {
                    Image(band.heroPicture)
                        .resizable()
                        .cornerRadius(10)
                        .frame(width: 80, height: 40)
                        .shadow(radius: 3)
                }
            }
        }
        .navigationTitle("Bands")
    }
}

struct TurkeyView_Previews: PreviewProvider {
    static var previews: some View {
        TurkeyView()
    }
}
